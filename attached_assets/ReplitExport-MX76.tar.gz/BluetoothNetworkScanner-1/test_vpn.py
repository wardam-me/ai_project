# Ce fichier sera remplacé dans une future mise à jour
# Le VPN sera géré localement